export abstract class Empregado {

    private nome: string;
    private cpf: string;

    public constructor(_nome:string, _cpf:string){
         this.nome = _nome;
         this.cpf = _cpf;
    }

    public abstract vencimento(): number;
}


